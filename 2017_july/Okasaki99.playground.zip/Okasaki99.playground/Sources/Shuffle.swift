import Foundation

extension Sequence {
    public func shuffled() -> [Element] {
        var elements = Array(self)
        for i in 0 ..< elements.count - 1 {
            let j = i + Int(arc4random_uniform(UInt32(elements.count - i)))
            if i != j {
                (elements[i], elements[j]) = (elements[j], elements[i])
            }
        }
        return elements
    }
}
