
import Cocoa

extension SearchTree : CustomPlaygroundQuickLookable {
    public var customPlaygroundQuickLook: PlaygroundQuickLook {
        guard let image = self.imageRepresentation?.image else { return .text("nil") }
        return .image(image)
    }
}

extension Color {
    var nsColor: NSColor {
        switch self {
        case .black: return .black
        case .red: return .red
        }
    }
}

extension SearchTree {
    private static func nodeImage(_ color: Color, _ value: Element) -> NSImage {
        let width: CGFloat = 32
        let fontSize: CGFloat = 16
        let image = NSImage(size: CGSize(width: width, height: width), flipped: true) { bounds in
            color.nsColor.setFill()
            NSBezierPath(ovalIn: bounds).fill()
            let label = NSAttributedString(
                string: "\(value)",
                attributes: [
                    .foregroundColor: NSColor.white,
                    .font: NSFont.systemFont(ofSize: fontSize)
                ])
            let labelSize = label.size()
            label.draw(in: CGRect(x: bounds.midX - labelSize.width / 2,
                                  y: bounds.midY - labelSize.height / 2,
                                  width: labelSize.width,
                                  height: labelSize.height))
            return true
        }
        image.matchesOnMultipleResolution = false
        return image
    }
    
    var imageRepresentation: (image: NSImage, rootPosition: CGFloat)? {
        guard case let .node(color, value, left, right) = self else { return nil }
        let nodeImage = SearchTree.nodeImage(color, value)
        let leftImage = left.imageRepresentation
        let rightImage = right.imageRepresentation
        let hpadding: CGFloat = 24
        let vpadding: CGFloat = 12
        
        let halfNode = nodeImage.size.width / 2
        
        let height = nodeImage.size.height + (leftImage != nil || rightImage != nil ? vpadding : 0)
            + max(leftImage?.image.size.height ?? 0, rightImage?.image.size.height ?? 0)
        
        switch (leftImage, rightImage) {
        case let (leftImage?, rightImage?):
            let leftWidth = max(leftImage.image.size.width + hpadding / 2, halfNode)
            let rightWidth = max(rightImage.image.size.width + hpadding / 2, halfNode)
            
            let image = NSImage(size: CGSize(width: leftWidth + rightWidth, height: height), flipped: true) { bounds in
                let rootCenter = CGPoint(x: leftWidth, y: nodeImage.size.height / 2)
                let lp = CGPoint(x: leftWidth - hpadding / 2 - leftImage.image.size.width,
                                 y: nodeImage.size.height + vpadding)
                let rp = CGPoint(x: leftWidth + hpadding / 2,
                                 y: nodeImage.size.height + vpadding)
                
                NSColor.black.setStroke()
                let lline = NSBezierPath()
                lline.move(to: rootCenter)
                lline.line(to: CGPoint(x: lp.x + leftImage.rootPosition, y: lp.y + nodeImage.size.height / 2))
                lline.stroke()
                leftImage.image.draw(in: CGRect(origin: lp, size: leftImage.image.size))
                
                let rline = NSBezierPath()
                rline.move(to: rootCenter)
                rline.line(to: CGPoint(x: rp.x + rightImage.rootPosition, y: rp.y + nodeImage.size.height / 2))
                rline.stroke()
                rightImage.image.draw(in: CGRect(origin: rp, size: rightImage.image.size))
                
                nodeImage.draw(in: CGRect(origin: CGPoint(x: leftWidth - halfNode, y: 0), size: nodeImage.size))
                return true
            }
            return (image, leftWidth)
        case let (leftImage?, nil):
            let leftWidth = leftImage.rootPosition + halfNode + hpadding / 2
            let rightWidth = max(leftImage.image.size.width - leftWidth, hpadding / 2 + halfNode)
            
            let image = NSImage(size: CGSize(width: leftWidth + rightWidth, height: height), flipped: true) { bounds in
                let rootCenter = CGPoint(x: leftWidth, y: nodeImage.size.height / 2)
                let lp = CGPoint(x: 0, y: nodeImage.size.height + vpadding)
                
                NSColor.black.setStroke()
                let lline = NSBezierPath()
                lline.move(to: rootCenter)
                lline.line(to: CGPoint(x: lp.x + leftImage.rootPosition, y: lp.y + nodeImage.size.height / 2))
                lline.stroke()
                leftImage.image.draw(in: CGRect(origin: lp, size: leftImage.image.size))
                
                nodeImage.draw(in: CGRect(origin: CGPoint(x: leftWidth - halfNode, y: 0), size: nodeImage.size))
                return true
            }
            return (image, leftWidth)
            
        case let (nil, rightImage?):
            let p = rightImage.rootPosition - halfNode - hpadding / 2
            let leftWidth = max(p, halfNode)
            let rightWidth = rightImage.image.size.width - rightImage.rootPosition + halfNode + hpadding / 2
            
            let image = NSImage(size: CGSize(width: leftWidth + rightWidth, height: height), flipped: true) { bounds in
                let rootCenter = CGPoint(x: leftWidth, y: nodeImage.size.height / 2)
                NSColor.black.setStroke()
                let rp = CGPoint(x: leftWidth + hpadding / 2 + halfNode,
                                 y: nodeImage.size.height + vpadding)
                let rline = NSBezierPath()
                rline.move(to: rootCenter)
                rline.line(to: CGPoint(x: rp.x, y: rp.y + nodeImage.size.height / 2))
                rline.stroke()
                rightImage.image.draw(in: CGRect(origin: CGPoint(x: rp.x - rightImage.rootPosition, y: rp.y),
                                                 size: rightImage.image.size))
                
                nodeImage.draw(in: CGRect(origin: CGPoint(x: leftWidth - halfNode, y: 0), size: nodeImage.size))
                return true
            }
            return (image, leftWidth)
            
        default:
            return (nodeImage, halfNode)
        }
    }
}
