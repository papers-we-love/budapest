import Cocoa

public enum Color {
    case red
    case black
}

public enum SearchTree<Element: Comparable> {
    case empty
    indirect case node(Color, Element, SearchTree, SearchTree)
}

extension SearchTree {
    public func forEach(_ body: (Element) -> Void) {
        switch self {
        case .empty:
            return
        case let .node(_, value, left, right):
            left.forEach(body)
            body(value)
            right.forEach(body)
        }
    }
}

extension SearchTree {
    public func inserted(_ value: Element) -> SearchTree {
        switch _inserted(value) {
        case let .node(.red, value, left, right):
            return .node(.black, value, left, right)
        case let node:
            return node
        }
    }

    func _inserted(_ value: Element) -> SearchTree {
        switch self {
        case .empty:
            return .node(.red, value, .empty, .empty)
        case let .node(color, element, left, right) where value < element:
            return balanced(color, element, left._inserted(value), right)
        case let .node(color, element, left, right) where value > element:
            return balanced(color, element, left, right._inserted(value))
        default:
            return self
        }
    }

    func balanced(_ color: Color, _ element: Element, _ left: SearchTree, _ right: SearchTree) -> SearchTree {
        switch (color, element, left, right) {
        case let (.black, z, .node(.red, y, .node(.red, x, a, b), c), d):
            return .node(.red, y, .node(.black, x, a, b), .node(.black, z, c, d))
        case let (.black, z, .node(.red, x, a, .node(.red, y, b, c)), d):
            return .node(.red, y, .node(.black, x, a, b), .node(.black, z, c, d))
        case let (.black, x, a, .node(.red, z, .node(.red, y, b, c), d)):
            return .node(.red, y, .node(.black, x, a, b), .node(.black, z, c, d))
        case let (.black, x, a, .node(.red, y, b, .node(.red, z, c, d))):
            return .node(.red, y, .node(.black, x, a, b), .node(.black, z, c, d))
        default:
            return .node(color, element, left, right)
        }
    }
}

extension SearchTree {
    public func contains(_ value: Element) -> Bool {
        switch self {
        case .empty:
            return false
        case let .node(_, element, left, _) where value < element:
            return left.contains(value)
        case let .node(_, element, _, right) where value > element:
            return right.contains(value)
        default:
            return true
        }
    }
}
