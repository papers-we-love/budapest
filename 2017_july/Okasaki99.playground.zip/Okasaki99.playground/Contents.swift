import Cocoa



SearchTree<Int>.node(.red, 42, .node(.black, 12, .empty, .empty), .empty)


let tree = (0 ..< 100).shuffled().reduce(SearchTree<Int>.empty) { tree, value in
    tree.inserted(value)
}
tree





